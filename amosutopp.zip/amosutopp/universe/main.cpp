#include "universe.hpp"
#include <iostream>

int main() {
    // Initialize the Universe with a trajectory and topology file
    Universe universe("../devel/static.dcd", "../devel/structure.data");

    // Print information about the Universe (frames, atoms, masses, etc.)
    universe.print_info();

    // Set to a specific frame (for example, frame 2)
    universe.set_frame_number(2);

    // Print updated information after setting the frame
    std::cout << "\nAfter setting frame 2:" << std::endl;
    universe.print_info();

    return 0;
}