// base.cpp
#include "base.h"

// If in the future you have non-virtual functions or 
// default implementations in the Base class, you can define them here.